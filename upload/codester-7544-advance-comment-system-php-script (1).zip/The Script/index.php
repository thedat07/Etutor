<?php 
require('config/config.php');

if(isset($_POST['submit'])) {
  $name = $_POST['name'];
  $color = $_POST['color'];
  $avater = $_POST['avater'];
  $comment = $_POST['comment'];

  $query = "INSERT INTO comments (cmt_name, cmt_color, cmt_avater, cmt_body, cmt_date) ";
  $query .= "VALUES ('$name' , '$color', '$avater', '$comment', NOW())";

  $go = mysqli_query($con, $query);
  if(!$go) {
    die("Error connection" . mysqli_error($con));
  }
}






 ?>





<!DOCTYPE html>
<html lang="en">
<head>
    <title>Commenting System</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="cool/animate.css">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="custom.css">
</head>
<body>
    <div class="container">

      <div class="col-lg-9 offset-lg-2 col-12 comment-main rounded">
        <form ation="" method="post">
        <div class="form-gtoup">
          <label>Your Name</label>
        <input name="name" class="form-control" type="text" required>
        </div>

        <div class="form-gtoup">
          <label>Select Your Text Color:</label>
        <input name="color" class="form-control" type="color">
        </div>
        <div class="form-gtoup">
          <label>Select Avater</label>
        <table width="100%" align="center">
          <tr>
          <td width="10%"><input type="radio" name="avater" value="boy.png" required><img src="image/boy.png" width="40"></td>
          <td width="10%"><input type="radio" name="avater" value="boy-1.png" required><img src="image/boy-1.png" width="40"></td>
          <td width="10%"><input type="radio" name="avater" value="boy-2.png" required><img src="image/boy-2.png" width="40"></td>
          <td width="10%"><input type="radio" name="avater" value="boy-3.png" required><img src="image/boy-3.png" width="40"></td>
          <td width="10%"><input type="radio" name="avater" value="boy-4.png" required><img src="image/boy-4.png" width="40"></td>
        </tr>
        <tr>
        <td width="10%"><input type="radio" name="avater" value="girl.png" required><img src="image/girl.png" width="40"></td>
          <td width="10%"><input type="radio" name="avater" value="girl-1.png" required><img src="image/girl-1.png" width="40"></td>
          <td width="10%"><input type="radio" name="avater" value="girl-2.png" required><img src="image/girl-2.png" width="40"></td>
          <td width="10%"><input type="radio" name="avater" value="girl-3.png" required><img src="image/girl-3.png" width="40"></td>
          <td width="10%"><input type="radio" name="avater" value="girl-4.png" required><img src="image/girl-4.png" width="40"></td>
        </tr>
        </table>
        </div>

        <div class="form-gtoup">
          <label>Your Comment:</label>
        <textarea name="comment" class="form-control" rows="8"> </textarea>
        </div>
        <br>

        <button name="submit" type="submit" class="btn btn-primary btn-block"><b>Submit Comment</b></button>
        <br>
        </form>




      </div>
      <hr>



      <?php 


      $comments = mysqli_query($con, "SELECT * FROM comments ORDER BY cmt_id DESC");
      while($row = mysqli_fetch_assoc($comments)) {
        $name = $row['cmt_name'];
        $color = $row['cmt_color'];
        $avater = $row['cmt_avater'];
        $body = $row['cmt_body'];
        $date = $row['cmt_date'];

        ?>        
      



       



    
      <div class="row">
        <div class="col-lg-9 offset-lg-2 col-12 comment-main rounded">
          <ul class="p-0">
            <li class="wow fadeInUp">
                <div class="row comment-box p-2 pt-4 pr-5">
                  <div class="col-lg-2 col-3 user-img text-center">
                    <img src="image/<?php echo $avater; ?>" class="main-cmt-img">
                  </div>
                  <div class="col-lg-10 col-9 user-comment bg-light rounded pb-1">
                       <div class="row">
                             <div class="col-lg-8 col-6 border-bottom pr-0">
                                <p class="w-100 p-2 m-0"><font color="<?php echo $color; ?>"><b><?php echo $body; ?></b></font></p>
                             </div>
                             <div class="col-lg-4 col-6 border-bottom">
                                <p class="w-100 p-2 m-0"><span class="float-right"><i class="fa fa-clock-o mr-1" aria-hidden="true"></i><?php echo $date; ?></span></p>
                             </div>
                       </div> 
                      <div class="user-comment-desc p-1 pl-2">
                          <p class="m-0 mr-2"><?php echo $name; ?></p>                      
                                                
                      </div>    
                  </div>
                </div>
            
                
            </li>
          </ul>
      </div>
    </div>
    <?php } ; ?>
<script src="cool/wow.min.js"></script>
              <script>
              new WOW().init();
              </script>
</body>
</html>